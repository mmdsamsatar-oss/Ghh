# Patch contract (template_version 1)

The builder app takes `template-unsigned.apk`, patches the entries below, then aligns and signs it.

| What | Where in the APK | How |
|---|---|---|
| Runtime settings | `assets/config.json` | replace file (schema in this repo) |
| Local HTML site | `assets/www/**` | replace/add files; set `type: html`, `html_entry` |
| Website mode | `assets/config.json` | set `type: url`, `url` |
| Icon | file(s) referenced by `@mipmap/ic_launcher` (mdpi..xxxhdpi PNG, resolve via resources.arsc) | replace PNG bytes |
| App name | `@string/app_name` in resources.arsc (placeholder "Template") | edit string pool |
| Package name | manifest `package` + resources.arsc package (placeholder `com.template.webapp`) | rename; activity class name stays `com.template.webapp.MainActivity` (fully qualified in manifest) |
| Version | manifest versionCode / versionName | edit |

Constraints to keep when rewriting the APK:
- `resources.arsc` must stay STORED (uncompressed) and 4-byte aligned (targetSdk 34).
- Re-run zipalign, then sign with v1+v2 (apksig) using the builder's own key.
- Status bar/background colors, orientation etc. are applied at runtime from config.json; no resource patching needed.

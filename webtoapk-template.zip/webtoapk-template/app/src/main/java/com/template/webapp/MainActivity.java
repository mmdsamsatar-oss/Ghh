package com.template.webapp;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Generic WebView shell. Everything app-specific is read at runtime from
 * assets/config.json (and assets/www/ in "html" mode), so a builder app can
 * patch those files inside the APK without recompiling.
 */
public class MainActivity extends Activity {

    private static final int FILE_REQ = 1001;

    private WebView webView;
    private JSONObject cfg = new JSONObject();
    private String baseHost = "";
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            cfg = new JSONObject(readAsset("config.json"));
        } catch (Exception ignored) { }

        if (cfg.optBoolean("fullscreen", false)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        if (cfg.optBoolean("keep_screen_on", false)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        String orientation = cfg.optString("orientation", "auto");
        if ("portrait".equals(orientation)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if ("landscape".equals(orientation)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }

        try {
            getWindow().setStatusBarColor(Color.parseColor(cfg.optString("status_bar_color", "#1E88E5")));
        } catch (Exception ignored) { }

        webView = new WebView(this);
        try {
            webView.setBackgroundColor(Color.parseColor(cfg.optString("background_color", "#FFFFFF")));
        } catch (Exception ignored) { }
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(cfg.optBoolean("javascript", true));
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setBuiltInZoomControls(cfg.optBoolean("zoom", false));
        s.setDisplayZoomControls(false);
        String ua = cfg.optString("user_agent", "");
        if (!ua.isEmpty()) {
            s.setUserAgentString(ua);
        }

        final String startUrl;
        if ("url".equals(cfg.optString("type", "html"))) {
            startUrl = cfg.optString("url", "about:blank");
            String h = Uri.parse(startUrl).getHost();
            baseHost = h == null ? "" : h;
        } else {
            startUrl = "file:///android_asset/www/" + cfg.optString("html_entry", "index.html");
        }

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleLink(request.getUrl());
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    String failed = request.getUrl().toString().replace("\"", "&quot;");
                    String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                            + "<body style='font-family:sans-serif;text-align:center;padding:48px 16px'>"
                            + "<h3>No connection / اتصال برقرار نیست</h3>"
                            + "<p><a href=\"" + failed + "\">Retry / تلاش مجدد</a></p></body></html>";
                    view.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) { }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(startUrl);
        }
    }

    private boolean handleLink(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();

        if (scheme.equals("http") || scheme.equals("https")) {
            boolean external = cfg.optBoolean("external_links_in_browser", true)
                    && !baseHost.isEmpty()
                    && uri.getHost() != null
                    && !uri.getHost().equals(baseHost);
            if (!external) {
                return false;
            }
        } else if (scheme.equals("file") || scheme.equals("about") || scheme.equals("data")) {
            return false;
        }

        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) { }
        return true;
    }

    private String readAsset(String name) throws Exception {
        InputStream is = getAssets().open(name);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) {
            bos.write(buf, 0, n);
        }
        is.close();
        return bos.toString("UTF-8");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
